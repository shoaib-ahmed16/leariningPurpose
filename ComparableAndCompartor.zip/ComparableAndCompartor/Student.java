package ComparableAndCompartor;

public class Student implements Comparable<Student>{

	private int id;
	private int age;
	private String name;
	private String batch;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBatch() {
		return batch;
	}
	public void setBatch(String batch) {
		this.batch = batch;
	}
	public Student() {
		
	}
	public Student(int id, int age, String name, String batch) {
		super();
		this.id = id;
		this.age = age;
		this.name = name;
		this.batch = batch;
	}
// if we want to give default sorting order on the bases of Id for this Student Object.
//	@Override
//	public int compareTo(Student student) {
//		// TODO Auto-generated method stub
//		if(this.id==student.id) {
//			return 0;
//		}
//		else if(this.id>student.id) {
//			return 1;
//		}
//		else
//			return -1;
//	}

	
	//if we want to give default sorting order on the bases of Age for this Student Object.
//	@Override
//	public int compareTo(Student student) {
//		// TODO Auto-generated method stub
//		if(this.age==student.age) {
//			return 0;
//		}
//		if(this.age>student.age) {
//			return 1;
//		}
//		else
//			return -1;
//	}
	
//	//if we want to give default sorting order on the bases of Name for this Student Object.
//	@Override
//	public int compareTo(Student student) {
//		// TODO Auto-generated method stub
//		return this.name.compareTo(student.name);
//	}
	
	//if we want to give default sorting order on the bases of Batch for this Student Object.
	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		return this.batch.compareTo(student.batch);
	}
	
}
