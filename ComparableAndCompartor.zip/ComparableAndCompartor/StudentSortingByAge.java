package ComparableAndCompartor;

import java.util.Comparator;

public class StudentSortingByAge  implements Comparator<Student> {
	//By implementing Compartor Interface in this Class, we are comparing 2 object of student class by their IDs and sorting accordingly
	@Override
	public int compare(Student obj1, Student obj2) {
		// TODO Auto-generated method stub
		// In this condition the ids of 2 student object is compare and if they are equals then we are not changing the order.
		if(obj1.getAge()==obj2.getAge()) {
			return 0;
		}
		// In this condition the ids of 2 student object is compare and if they the id of first object is greater then the second object then the order of object is change.
		else if(obj1.getAge()>obj2.getAge()) {
			return 1;
		}
		// In this condition the ids of 2 student object is compare and if they the id of first object is greater then the second object then the order of object is change.
		else{
			return -1;
			}
	}
}