package ComparableAndCompartor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparatorDemo {

	public static void main(String[] args) {
	//Example
	List<Student> studentList = new ArrayList<>(); //Collection Data Structure.
	// Adding details of student in different Student Object.
	// first student.	
		Student stud1= new Student();
			stud1.setId(1);
			stud1.setAge(20);
			stud1.setBatch("2019-2023");
			stud1.setName("Shoaib");
	// Second Student.
			Student stud2= new Student();
			stud2.setId(2);
			stud2.setAge(23);
			stud2.setBatch("2020-2023");
			stud2.setName("Shana");
	// Third Student.
			Student stud3= new Student();
			stud3.setId(3);
			stud3.setAge(25);
			stud3.setBatch("2022-2026");
			stud3.setName("Shivam");
			
	
		// Forth student.	
		Student stud4= new Student();
			stud4.setId(6);
			stud4.setAge(19);
			stud4.setBatch("2011-2015");
			stud4.setName("sonu");
		// fifth Student.
				Student stud5= new Student();
				stud5.setId(9);
				stud5.setAge(30);
				stud5.setBatch("2029-2033");
				stud5.setName("arjun");
		// Sixth Student.
				Student stud6= new Student();
				stud6.setId(5);
				stud6.setAge(15);
				stud6.setBatch("2024-2028");
				stud6.setName("rita");
	studentList.add(stud2);
	studentList.add(stud5);
	studentList.add(stud4);
	studentList.add(stud1);
	studentList.add(stud6);
	studentList.add(stud3);
	

		// sorting student list using class which is implementing the Comparator Interface to sort data using student ID.
		
	
		//1. Sorting on the bases of Id using comparator Interface.
		// Creating object of class which is implementing Comparator Interface.
		//StudentSortingById studId = new StudentSortingById();
		//Collections.sort(studentList,studId);
		// Printing the sorted Studentlist using  class which is implementing the Comparator Interface to sort data using student ID.
//		System.out.println("######## ID based sorting using Compartor Interface ######");
//		for(Student s:studentList) {
//			Student stud=s;
//			System.out.print("{ Student Id: "+stud.getId()+", Student Name:"+stud.getName()+", Student Batch:"+stud.getBatch()+", Student Age:"+stud.getAge()+" } \r\n");
//		}
		
		//2. Sorting on the bases of Age using comparator Interface.
		// Creating object of class which is implementing Comparator Interface.
		//StudentSortingByAge studAge = new StudentSortingByAge();
		//Collections.sort(studentList,studAge);
		// Printing the sorted Studentlist using  class which is implementing the Comparator Interface to sort data using student ID.
//		System.out.println("######## Age based sorting using Compartor Interface ######");
//		for(Student s:studentList) {
//			Student stud=s;
//			System.out.print("{ Student Id: "+stud.getId()+", Student Name:"+stud.getName()+", Student Batch:"+stud.getBatch()+", Student Age:"+stud.getAge()+" } \r\n");
//		}
		
		
		//3. Sorting on the bases of Name using comparator Interface.
		// Creating object of class which is implementing Comparator Interface.
		StudentSortingByName studName = new StudentSortingByName();
		Collections.sort(studentList,studName);
		//Printing the sorted Studentlist using  class which is implementing the Comparator Interface to sort data using student ID.
		System.out.println("######## Name based sorting using Compartor Interface ######");
		for(Student s:studentList) {
			Student stud=s;
			System.out.print("{ Student Id: "+stud.getId()+", Student Name:"+stud.getName()+", Student Batch:"+stud.getBatch()+", Student Age:"+stud.getAge()+" } \r\n");
		}
		
		//4. Sorting on the bases of Batch using comparator Interface.
		// Creating object of class which is implementing Comparator Interface.
//		StudentSortingByBatch studBatch = new StudentSortingByBatch();
//		Collections.sort(studentList,studBatch);
		// Printing the sorted Studentlist using  class which is implementing the Comparator Interface to sort data using student ID.
//		System.out.println("######## Batch based sorting using Compartor Interface ######");
//		for(Student s:studentList) {
//			Student stud=s;
//			System.out.print("{ Student Id: "+stud.getId()+", Student Name:"+stud.getName()+", Student Batch:"+stud.getBatch()+", Student Age:"+stud.getAge()+" } \r\n");
//		}
	}
}
