package ComparableAndCompartor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparableDemo {

	public static void main(String[] args) {
		//Comparable and Comparator both are interfaces and can be used to sort collection elements.
		
		
		
		// Arrays.sort(studentList); will not work here as this sorting  method is applicable for  java predefine Arrays
		// There is equivalent alternative we use to sort collection data stucture type.
		// we use : Collections.sort(varaible name);
		
//		Example
		List<Student> studentList = new ArrayList<>(); //Collection Data Structure.
		// Adding details of student in different Student Object.
		// first student.	
			Student stud1= new Student();
				stud1.setId(1);
				stud1.setAge(20);
				stud1.setBatch("2019-2023");
				stud1.setName("Shoaib");
		// Second Student.
				Student stud2= new Student();
				stud2.setId(2);
				stud2.setAge(23);
				stud2.setBatch("2020-2023");
				stud2.setName("Shana");
		// Third Student.
				Student stud3= new Student();
				stud3.setId(3);
				stud3.setAge(25);
				stud3.setBatch("2020-2023");
				stud3.setName("Shivam");
		studentList.add(stud2);
		studentList.add(stud3);
		studentList.add(stud1);
		studentList.add(stud1);
		studentList.add(stud2);
		studentList.add(stud3);
		studentList.add(stud3);
		studentList.add(stud2);
		studentList.add(stud1);
	
		// simple list like 
		List<Integer> list = new ArrayList<>();
			list.add(1);
			list.add(4);
			list.add(2);
			list.add(10);
			list.add(5);
			
		// Important Points to be noted.
		Collections.sort(list); // Internally collection store one last value it reach, and use it to compare with the upcoming index value.
		//1.this method easily sort the list which have primitive data type wrapper class object as List generic define.
//		Collections.sort(studentList, null);
		Collections.sort(studentList);
		//2. this same method fails to sort the List which is having multiple variable object as List generic define.
		
		// Printing the sorted Studentlist
		for(Student s:studentList) {
			Student stud=s;
			System.out.print("{ Student Id: "+stud.getId()+", Student Name:"+stud.getName()+", Student Batch:"+stud.getBatch()+", Student Age:"+stud.getAge()+" } \r\n");
		}
	}
	
}
